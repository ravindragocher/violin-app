import Ember from 'ember';
export default Ember.Component.extend({
    quesempty:false,
    timerempty:false,
    isqpreview:false,
    isfree:false,
    ismcsa:false,
    answerChoices:function(){
        var ansChoices;
        /*this.store.findRecord('contentquestions',this.get('selectedQuestionId')).then(function (item){
            ansChoice = item.get('answerChoice');
        });*/ //not working
        var q_id = this.get('selectedQuestionId');
        this.get('question').forEach(function (item){
            if (item.id === q_id){
                ansChoices = item.get('answerChoice');
            }

        });
        return ansChoices;

    }.property('selectedQuestionId'),

    qText:function(){
        var qtext;
        var qtype;
        var q_id = this.get('selectedQuestionText');
        this.get('question').forEach(function (item){
            if (item.id === q_id){
                qtext = item.get('question');
                qtype= item.get('questiontype');
            }
        });
        return qtext;

    }.property('selectedQuestionText'),


    qID:function(){

        var q_id = this.get('qId');

        return  q_id;

    }.property('qId'),

    qt:function(q_id){
var qt;
        this.get('question').forEach(function (item){
            if (item.id === q_id){
                qt= item.get('questiontype');
            }
        });
        return qt;

    },


    selectedQuestionId: 1,
    selectedQuestionText:1,
    qId:1,

    actions : {
    selectques: function(){
        var q_id = $("#quesselect").val();
        this.set('selectedQuestionId', q_id);
        this.set('selectedQuestionText',q_id);
        this.set('qId',q_id);
        var tt=this.qt(q_id);
        if(tt === "MCSA")
        {
        this.set('isqpreview',true);
        this.set('isfree',false);
        }

        else if (tt === "FREE") {
            this.set('isqpreview',false);
            this.set('isfree',true);
        }
    },
    addquestion: function(){
        var newquestionname = this.get('newquestion');
        var timer=this.get('timer');

        if(newquestionname=="" || newquestionname== undefined || newquestionname==" "){
            this.set("quesempty", true);
            this.set("timerempty", false);
        }
        else if (timer=="" || timer== undefined || timer==" ") {
            this.set("quesempty", false);
            this.set("timerempty", true);
        }
        else {
            this.set("quesempty", false);
            this.set("timerempty", false);
            this.sendAction('action',newquestionname);
        }
    },
    }
});
