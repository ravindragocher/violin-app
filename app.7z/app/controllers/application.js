import Ember from 'ember';
const {observer, computed, on, set:set} = Ember;

export default Ember.Controller.extend({
  
});
