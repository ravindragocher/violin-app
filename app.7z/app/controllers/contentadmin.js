import Ember from 'ember';

export default Ember.ObjectController.extend({
  isClickedForModule: false ,
  isClickedForTopic : false ,
  isClickedForQuestion:false,

actions : {

addmodule: function(newmodulename){
var newModule =  this.store.createRecord('content',
{
  module:newmodulename,
});
newModule.save();
},


selectmodule:function(){
  var e = document.getElementById("modselect");
  var strUser = e.options[e.selectedIndex].text;

alert(strUser);
},


addtopic: function(newtopicname){
var newTopic =  this.store.createRecord('contenttopic',
{
  topic:newtopicname,
});
newTopic.save();
},

addquestion: function(newquestionname){
var newQuestion =  this.store.createRecord('contentquestions',
{
  question:newquestionname,
});
newQuestion.save();
},

    clickonmodule: function(){
        this.toggleProperty('isClickedForModule');
        this.set('isClickedForTopic',false);
        this.set('isClickedForQuestion',false);
    },

    clickontopic: function(){
        this.toggleProperty('isClickedForTopic');
        this.set('isClickedForModule',false);
        this.set('isClickedForQuestion',false);
    },

    clickonQuestion: function(){
        this.toggleProperty('isClickedForQuestion');
        this.set('isClickedForModule',false);
        this.set('isClickedForTopic',false);
},

}
});
