import DS from 'ember-data';
export default DS.Model.extend({

answerChoice:DS.attr(),
question:DS.attr('string'),
questiontype:DS.attr('string'),
}).reopenClass({
  FIXTURES: [
      {
          id:1,
          question:"What are the types of linkages?",
          answerChoice:["A","B","Z"],
          questiontype:"MCMA",
      },
      {
        id:2,
        question:"Which of the following special symbol allowed in a variable name?",
        answerChoice:["C","D"],
         questiontype:"MCMA",
      },
      {
        id:3,
        question:"When we mention the prototype of a function?",
        answerChoice:["E","F"],
         questiontype:"MCSA",
      },
      {
        id:4,
        question:"How would you round off a value from 1.66 to 2.0?",
        answerChoice:["G","H"],
         questiontype:"MCSA",
      },
      {
        id:5,
        question:"By default a real number is treated as a-",
        answerChoice:["I","J"],
         questiontype:"MCSA",
      },
      {
        id:6,
        question:"Which of the following jobs are NOT performed by Garbage Collector?",
        answerChoice:["K","L"],
         questiontype:"MCSA",
     },
     {
       id:7,
       question:"Explain Yourself?",
        questiontype:"FREE",
    }
  ]
});
